#.....Data Types.....................

#String
"Hello"[4]

#Integer
print(123 + 345)

123_456_789

#FLOAT
3.14159

#Boolean
True
False



# Math operation
# +,-,*,%,/
x = 15
y = 2

print(x + y)
# print(x - y)
# print(x * y)
# print(x / y)
# print(x % y)



# Casting
# y = int(2.8) 
# z = int("3")
# y = float(2.8) 
# z = str(3.0)


# Exercise
# 🚨 Don't change the code below 👇
# two_digit_number = input("Type a two digit number: ")
# 🚨 Don't change the code above 👆

####################################
#Write your code below this line 👇

# output

# เราพิมพ์  12
# ผลลัพธ์คือ 1 + 2 = 3







# Lecture
# print(round(8 /3 ,2))
# 
# print( type(8 // 3))

# scroe = 0
# scroe +=1

# print("your score is "+ str(score))

# f-String
# print(f"your score is {scroe}")