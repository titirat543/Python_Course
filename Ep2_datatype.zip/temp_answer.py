from ctypes import c_int


print("เปลี่ยนอุณหภูมิจาก Celcius เป็น F และ K")

#input C
c = input("Celcius : ")

# แปลง input เป็น Float type
Celsius_number = float(c)

# ทำ Float type มาคำนวนนสูตรที่กำหนด
Fahrenheit = ((9/5)*Celsius_number) + 32
Kelvin = Celsius_number + 273.15

# แสดงผลลัพธ์จากการคำนวนในแต่ละสูตร
print(f"Fahrenheit : {Fahrenheit}")
print(f"Kelvin : {Kelvin}")
