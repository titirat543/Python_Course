print("เปลี่ยนอุณหภูมิจาก Celcius เป็น F และ K")

#input C
c = input("Celcius : ")

# แปลง input เป็น Float type

# ทำ Float type มาคำนวนนสูตรที่กำหนด


# แสดงผลลัพธ์จากการคำนวนในแต่ละสูตร