# Exercise
# 🚨 Don't change the code below 👇



two_digit_number = input("Type a two digit number: ")
# print(type(two_digit_number))
# 🚨 Don't change the code above 👆

####################################
#Write your code below this line 👇

# output

# เราพิมพ์  78
# ผลลัพธ์คือ 7 + 8 = 15
# ผลลัพธ์คือ 7 * 8 = 56
first_digit = int(two_digit_number[0])
second_digit = int(two_digit_number[1])

combine = first_digit + second_digit
multipy = first_digit * second_digit

print(combine)
print(multipy)
