
score = int(input("grade?; "))

if score >=80  and score <= 100:
    print("You grade is A")
elif score >=75  and score < 80:
     print("You grade is B+")
elif score >=70  and score < 75:
     print("You grade is B")
elif score >=65  and score < 70:
     print("You grade is C+")
elif score >=60  and score < 65:
     print("You grade is C")
elif score >=55  and score < 60:
     print("You grade is D+")
elif score >=50  and score < 55:
     print("You grade is D")
elif score >=0 and score < 50:
    print("You grade is F")
else:
    print("Not in the range or error")