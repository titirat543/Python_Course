# variable exercise
#1. Create a greeting for your program.
print("welcome to Miss Grand 2022\n")

#2. Ask the user เกี่ยวกับชื่อจริงของคน .


#3. Ask the user เกี่ยวกับนามสกุลของคน .

#4. Ask the user เกี่ยวกับชื่อของจังหวัด.


#5. print output .