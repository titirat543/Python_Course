# variable exercise
#1. Create a greeting for your program.
print("welcome to Miss Grand 2022\n")

#2. Ask the user เกี่ยวกับชื่อจริงของคน .
name = input("What is your name? ")

#3. Ask the user เกี่ยวกับนามสกุลของคน .
family_name = input("What is your last name? ")

#4. Ask the user เกี่ยวกับชื่อของจังหวัด.
province_name = input("What is your province? ")


#5. print output .
print(name+ " " + family_name + " from " + province_name)