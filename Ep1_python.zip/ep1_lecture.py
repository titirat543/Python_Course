# variable section
# different or not
print("Hello world!\nHello world")
print("Hello" + "Foey")
print("Hello" + " " + "Foey")
print("Hello "  + "Foey")

#input👇 function
name = input("Your name?")
length = len(name)
print(length)
print(length)





