#.....Data Types.....................

#String
# a = "Hello"[-5]
# print(a)


#Integer
# -inf->-1,0,1->inf
# print(type(123 + 345))
# print(type(0))
# print(type(-1))

123_456_789

#FLOAT
p = 3.14159
# print(type(p))

#Boolean
True
False



# Math operation
# +,-,*,%,/
x = 18
y = 4

# print(x + y)
# print(x - y)
# print(x * y)
# print(x / y)
# print(x % y)



# Casting
nu = 2.8
# print(type(nu))
y = int(nu)
# print(type(y))
z = int("3")
y = float(2.8)
z = str(3)
# print(type(z))











# Lecture
# print((8/3)+5)
# print(round(8/3,1))
#
# print(8//3)
# print(type(8//3))

scroe = 0
# number = scroe + 1
# print(number)
scroe +=1
# print("Basketball Score is " + scroe)

# print("your score is "+ str(scroe))

# f-String
print(f"your score is {scroe}")