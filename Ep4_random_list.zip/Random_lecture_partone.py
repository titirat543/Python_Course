

# Random_lesson ep 4
import random


# question = input("Heads or Tails? ")
# coin lesson
# coin = random.randint(1,2)

# if coin == 1:
#     print('Heads')
# else:
#     print('Tails')

# Dice lesson
# dice = random.randint(1,6)
# print(f"Dice total : {dice}")

# Chalenge 2 => 3 six-faced dice
# three_dice = random.randint(3,18)
# print(f"3-Dice total : {three_dice}")

# Chalenge 3 => 6 Dif-face dice
dif = random.randint(6,60)
print(f"6-Dice total : {dif}")



