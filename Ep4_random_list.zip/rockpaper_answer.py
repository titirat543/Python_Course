rock = '''
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
'''

paper = '''
    _______
---'   ____)____
          ______)
          _______)
         _______)
---.__________)
'''

scissors = '''
    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)
'''
import random

print("Welcopme to RPS completition")
you = input("choose 0(rock),1(paper),2(scissor)\n")

list_rps = [rock,paper,scissors]

# Todo 1: ต้องรู้ก่อนว่า เราจะออกอะไร
if you == '0':
    print('เราออกค้อน :' + list_rps[0])
elif you == '1':
    print('เราออกกระดาษ :' + list_rps[1])
elif you == '2':
    print('เราออกกรรไกร :' + list_rps[2])

# Todo 2: computer random
com_choice = random.randint(0,2)
com_choice_str = str(com_choice)

if com_choice_str == '0':
    print('คอมออกค้อน :' + list_rps[0])
elif com_choice_str == '1':
    print('คอมออกกระดาษ :' + list_rps[1])
elif com_choice_str == '2':
    print('คอมออกกรรไกร :' + list_rps[2])


# Todo 3:ตัดสินแพ้ชนะ
# เราต้องการชนะ
if you == '0' and com_choice_str == '2' or you == '1' and com_choice_str == '0' or you == '2' and com_choice_str == '1':
    print("เราชนะในเกมส์นี้")
# เราแพ้
elif you == '0' and com_choice_str == '1' or you == '1' and com_choice_str == '2' or you == '2' and com_choice_str == '0':
    print("แกแพ้ละ 5555")
# เราเสมอ/
else:
    print("เสมอเด้อ")