from imaplib import Time2Internaldate
import random

random_interger = random.randint(1,10)

random_float = random.random()

#  H and tail 

name = 'Titirat'

# print([0])

# Store group piece of data
fruits = ["Mango","apple","ORANGE"]

# add new items

# print(fruits[2])
name_list = ['Kimberry','Yaya','Makie','Mai']

num_of_list =  len(name_list)

print(num_of_list )

print(list[num_of_list])

