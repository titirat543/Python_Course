# fruits = ["Apple","Peach","Pear","Banana"]
# print(len(fruits))
# for x in fruits:
#    print(x)
#   print(fruit + "pie")


# for number in range(1,11):
#   print(number)







# for number in range(1,11,3):
#   print(number)