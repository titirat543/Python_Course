
# input first to make list
date_data = input("Input a date like this 10 2547: ").split(" ")
for n in range(0, len(date_data)):
  date_data[n] = int(date_data[n])
  if n == 1 :
    date_data[1] = date_data[1] - 543
# [10,2557]
# check year divide by 4
print(date_data)
print(date_data[1])
if date_data[1] % 4 == 0:
    # Yes condition
    # check year divide by 100
    if date_data[1] % 100 == 0:
        # check year divide by 400
         if date_data[1] % 400 == 0:
            print("Leaf year")
            if date_data[0] == 1 or date_data[0] == 3 or date_data[0] == 5 or date_data[0] == 7 or date_data[0] == 8 or date_data[0] == 10 or date_data[0] == 12:
                print("31")
            elif date_data[0] == 2:
                print("29")
            else:
                print('30')
         else:
            print("no Leaf year")
            if date_data[0] == 1 or date_data[0] == 3 or date_data[0] == 5 or date_data[0] == 7 or date_data[0] == 8 or date_data[0] == 10 or date_data[0] == 12:
                print("31")
            elif date_data[0] == 2:
                print("28")
            else:
                print('30')
    else:
        print("Leaf year")
        if date_data[0] == 1 or date_data[0] == 3 or date_data[0] == 5 or date_data[0] == 7 or date_data[0] == 8 or date_data[0] == 10 or date_data[0] == 12:
            print("31")
        elif date_data[0] == 2:
            print("29")
        else:
            print('30')
       

# No condition
else:
    if date_data[0] == 1 or date_data[0] == 3 or date_data[0] == 5 or date_data[0] == 7 or date_data[0] == 8 or date_data[0] == 10 or date_data[0] == 12:
        print("31")
    elif date_data[0] == 2:
        print("28")
    else:
        print('30')