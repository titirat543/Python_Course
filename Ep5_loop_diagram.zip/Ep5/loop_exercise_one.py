# 🚨 Don't change the code below 👇
student_weight = input("Input a list of student weight ").split()
for n in range(0, len(student_weight)):
  student_weight[n] = int(student_weight[n])
# 🚨 Don't change the code above 👆
print(student_weight)
total = 0
for n in range (0, len(student_weight)):
    student_weight[n] = student_weight[n]+ total
    # print(student_weight[n])
    total = student_weight[n]
    
    # print(total)
print(f"total : {total}")
aver = float(total / len(student_weight))
print(aver)







#Write your code below this row 👇
# total = 0
# for n in range(0, len(student_heights)):
#   student_heights[n] += total
#   total = student_heights[n]




# print(f"The sum is ",total)

# average = int(total / len(student_heights))
# print(f"The average is ",average)
