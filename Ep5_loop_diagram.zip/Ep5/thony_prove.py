fruits = ["Apple","Peach","Pear"]
for fruit in fruits:
    print(fruit + "pie")
    