# 🚨 Don't change the code below 👇
student_scores = input("Input a list of student scores ").split()
for n in range(0, len(student_scores)):
  student_scores[n] = int(student_scores[n])
print(student_scores)
# 🚨 Don't change the code above 👆
# 20  10 30 40 50
#Write your code below this row 👇
max = 0
for number in range(0, len(student_scores)):
  if max < student_scores[number]:
    max = student_scores[number]
  else:
    max = max

  

print(f"The maximum number is ",max)











